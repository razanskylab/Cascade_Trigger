#include "TriggerBoard.h"

TriggerBoard::TriggerBoard()
{
	// define all of our boards output pins and set them to an initial low
	#pragma unroll
	for (unsigned char iPin = 0; iPin < 3; iPin++)
	{
		pinMode(TRIG_PINS[iPin], OUTPUT);
		digitalWrite(TRIG_PINS[iPin], LOW);
	}

	// define all of the LED pins as outputs and set them to an initial low
	#pragma unroll
	for (unsigned char iPin = 0; iPin < 4; iPin++)
	{
		pinMode(STATUS_LED[iPin], OUTPUT);
		digitalWrite(STATUS_LED[iPin], LOW);
	}

	Serial.begin(115200);

}

// wait until a certain number of serial bytes arrived
void Triggerboard::wait_for_serial(const int nSerial)
{
	while(Serial.available() < nSerial)
	{
		delayMicroseconds(1);
	}
	return;
}

uint32_t serialReadUint32()
{
	union
	{
		
	}
}